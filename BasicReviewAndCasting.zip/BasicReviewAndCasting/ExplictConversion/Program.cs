﻿using System;
/** 
 * Name: Tao Ji Yang
 * Courses: NMAD.180:PROGRAMMING FUNDAMENTALS I:MOBILE DOMAIN
 * Due Date; 2/10/2021
 * Purpose: The purpose of this Part 3 is just simply find a way to use Int and parse to get three grade and be able to indicate the class average with PEDMAS and divide by number of grade as well.
 * Caveats: There no issues, but I did try to use string but I remember that using string and to int won't work. I realized that int is the only way to use unless if I wanna use double too but int and double both work. I add some decimal just to see if I can connect int and demcial without interruption however knowing that int to demcial is sign of IMPLICIT! So the goal for this to make sure it run EXPLICT Conversion. 
 */
namespace ExplictConversion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please give me the result for your first grade: ");

            int grade1 = int.Parse(Console.ReadLine());


            Console.WriteLine("Please give me the result for your second grade: ");
            int grade2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Please give me the result for your third grade: ");
            int grade3 = int.Parse(Console.ReadLine());

            decimal ValueofThree = 3;
            decimal divideOfTotalGrade = (grade1 + grade2 + grade3) / ValueofThree;


            Console.WriteLine("So your class average grade is: " + divideOfTotalGrade);

        }
    }
}

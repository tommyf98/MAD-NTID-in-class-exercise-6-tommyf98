﻿using System;
/** 
 * Name: Tao Ji Yang
 * Courses: NMAD.180:PROGRAMMING FUNDAMENTALS I:MOBILE DOMAIN
 * Due Date; 2/10/2021
 * Purpose: How to do PEDMAS base on short statement error such as string firstName = Grace; when you suppose to write string firstName = "Grace";.

 * Caveats: Number 17, Did not have space between sold so I add space and also add (widetsSold + 7) which will let the program know to do math problem in PEDMAS order. Line 15 did not have quotation mark for spring (So I added quotation mark to make sure the code was succesfful).
 */
namespace ImplicitConversion
{
    class Program
    {
        static void Main(string[] args)
        {
        string firstName = "Graces";
        int widgetsSold = 7;
        Console.WriteLine(firstName + " sold " + ( widgetsSold + 7 )+ " widgets. ");
        }


    
    }
}

﻿using System;
/** 
 * Name: Tao Ji Yang
 * Courses: NMAD.180:PROGRAMMING FUNDAMENTALS I:MOBILE DOMAIN
 * Due Date; 2/10/2021
 * Purpose: Working on C# string interpolation. Goal to have every string output to indicate with just using 0-8. 
 * Caveats: Number 38, format exception kept being thrown out. 
 */
namespace MadLibs
{
    class Program
    {
        static void Main(string[] args)
        {

            //Part 1//
            Console.Write("Enter a verb in present tense: ");
            string verb = Console.ReadLine();

            Console.Write("Enter a place: ");
            string place = Console.ReadLine();

            Console.Write("Enter a celebrity's name: ");
            string nameOfCelebrity = Console.ReadLine();

            Console.Write("Enter a friend's name: ");
            string nameOfFriend = Console.ReadLine();

            Console.Write("Enter an adjective: ");
            string adjective = Console.ReadLine();

            Console.Write("Enter a vehicle name and model and year: ");
            string vehicle = Console.ReadLine();

            Console.Write("Enter a noun: ");
            string noun = Console.ReadLine();

            Console.Write("Enter a number between 1 and 10: ");
            int number = int.Parse(Console.ReadLine());

            Console.Write("Enter a dollar value with cents included: ");
            double currency = double.Parse(Console.ReadLine());

            
            Console.WriteLine("Once upon a time, there was a {0} {1}. It was really {0}. \n It liked to {2} all the time. \n One day, the {1} went to {3} to see {4}. To get there, it rode in a {5} with {6}, but on the way \n, the {5} crashed. It took {7} hours for the {0} {1} and {6} to walk the rest of the way. \n There was ${8} with the damage to the {5}  ", adjective, noun, verb, place, nameOfCelebrity, vehicle , nameOfFriend, number, currency  );
            //Completed//


            //Part 2//

        }
    }
}
